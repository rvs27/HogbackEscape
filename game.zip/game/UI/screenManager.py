from FSMs import ScreenManagerFSM
from . import TextEntry, EventMenu
from utils import vec, RESOLUTION, SoundManager
from gameObjects.engine import GameEngine

from pygame.locals import *

class ScreenManager(object):
      
    def __init__(self):
        self.game = GameEngine() ## can be used for game restart
        self.state = ScreenManagerFSM(self)
        self.pausedText = TextEntry(vec(0,0),"Paused")
        
        size = self.pausedText.getSize()
        midpoint = RESOLUTION // 2 - size
        self.pausedText.position = vec(*midpoint)
        
        self.mainMenu = EventMenu("background.png", fontName="default8")
        self.mainMenu.addOption("start", "Press 1 to start Game",
                                 RESOLUTION // 2 - vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_1,
                                 center="both")
        self.mainMenu.addOption("exit", "Press 2 to exit Game",
                                 RESOLUTION // 2 + vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_2,
                                 center="both")
        
        
        self.winMenu = EventMenu("background.png", fontName="default8")
        self.winMenu.addOption("restart", "You escaped! Press 1 to play again",
                                 RESOLUTION // 2 - vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_1,
                                 center="both")
        self.winMenu.addOption("exit", "Press 2 to exit game",
                                 RESOLUTION // 2 + vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_2,
                                 center="both")
        

        self.loseMenu = EventMenu("background.png", fontName="default8")
        self.loseMenu.addOption("restart", "You lost! Press 1 to play again",
                                 RESOLUTION // 2 - vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_1,
                                 center="both")
        self.loseMenu.addOption("exit", "Press 2 to exit game",
                                 RESOLUTION // 2 + vec(0,50),
                                 lambda x: x.type == KEYDOWN and x.key == K_2,
                                 center="both")
    
        
    
    def draw(self, drawSurf):
        if self.state.isInGame():
            self.game.draw(drawSurf)
        
            if self.state == "paused":
                self.pausedText.draw(drawSurf)
        
        elif self.state == "mainMenu":
            self.mainMenu.draw(drawSurf)

        elif self.state == "winMenu":
            self.winMenu.draw(drawSurf)

        elif self.state == "loseMenu":
            self.loseMenu.draw(drawSurf)
    
    def handleEvent(self, event):

        sm = SoundManager.getInstance()

        if self.state in ["game", "paused"]:
            if event.type == KEYDOWN and event.key == K_m:
                self.state.quitGame()
            elif event.type == KEYDOWN and event.key == K_p:
                self.state.pause()
                
            else:
                self.game.handleEvent(event)
        elif self.state == "mainMenu":
            choice = self.mainMenu.handleEvent(event)
            sm.playBGM("mainMenu.mp3")
            
            if choice == "start":
                self.state.startGame()
                sm.playBGM("background.mp3")
            elif choice == "exit":
                return "exit"
            

        elif self.state in ["winMenu", "loseMenu"]:
            choice = self.winMenu.handleEvent(event)
            sm.playBGM("mainMenu.mp3")
            
            if choice == "restart":
                self.state.restartGame()
                self.game = GameEngine()
                sm.playBGM("background.mp3")
            elif choice == "exit":
                return "exit"
     
    
    def update(self, seconds):      
        if self.state == "game":
            result = self.game.update(seconds)
            self.game.update(seconds)
            if result == "win":
                self.state.winGame()
            elif result == "lose":
                self.state.loseGame()
        elif self.state == "mainMenu":
            self.mainMenu.update(seconds)
        '''
        elif self.state == "winMenu":
            self.winMenu.update(seconds)
        elif self.state == "loseMenu":
            self.loseMenu.update(seconds)
        '''