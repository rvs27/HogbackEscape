import pygame

from . import Drawable, Player
from random import randint, choice
from utils import vec, RESOLUTION, rectAdd


'''
            collision detection with trees - how to make it so player cant go through it
            talk about current design for random exit/trees -- its all in init

            how to prevent objects from being on top of one another
'''

class GameEngine(object):

    def __init__(self):       
        self.player = Player((450,300))
        self.hunter = Drawable((10,0), "hunter.png")
        self.size = vec(*RESOLUTION)
        self.background = Drawable((0,0), "background.png")
        self.keys = []
        self.trees = []
        x_options = [0,450,940]
        x_exit = choice(x_options)
        if x_exit == 0 or x_exit == 940:
            self.exit = Drawable((x_exit,330), "exit.png")
        else:
            y_exit = [0,675]
            self.exit = Drawable((x_exit, choice(y_exit)), "exit.png")

        for i in range(5):    #needs to inforce keys are not on top of one another
            x = randint(0,900)
            y = randint(0,600)
            self.keys.append(Drawable((x,y), "key.png"))
        
        for i in range(8):  # unsure of what number to add
            x = randint(0,900)
            y = randint(0,600)
            self.trees.append(Drawable((x,y), "tree.png"))


    def draw(self, drawSurface):        
        #self.background.draw(drawSurface)
        drawSurface.fill((0,40,13))
        
        self.player.draw(drawSurface)
        for k in self.keys:
            k.draw(drawSurface)

        for t in self.trees:
            t.draw(drawSurface)
        

        self.hunter.draw(drawSurface)
        
        if len(self.keys) == 0:
            self.exit.draw(drawSurface)
        

    def handleEvent(self, event):
        self.player.handleEvent(event)

    
    def update(self, seconds):
        self.player.update(seconds)

        
        if self.player.position[0] > self.hunter.position[0]:
            self.hunter.position[0] += 1
        else:
            self.hunter.position[0] -= 1
        if self.player.position[1] > self.hunter.position[1]:
            self.hunter.position[1] += 1
        else:
            self.hunter.position[1] -= 1
        

        playerHitBox = rectAdd(self.player.position, self.player.image.get_rect())

        for k in range(len(self.keys)):
            keyHitBox = rectAdd(self.keys[k].position, self.keys[k].image.get_rect())
            if keyHitBox.colliderect(playerHitBox):
                self.keys.pop(k)
                break

        exitHitBox = rectAdd(self.exit.position, self.exit.image.get_rect())
        if len(self.keys) == 0:
            if exitHitBox.colliderect(playerHitBox):
                return "win"
            
        hunterHitBox = rectAdd(self.hunter.position, self.hunter.image.get_rect())
        if hunterHitBox.colliderect(playerHitBox):
            return "lose"
            
        Drawable.updateOffset(self.player, self.size)
    

# cliprect 