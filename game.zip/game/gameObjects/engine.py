import pygame

from . import Drawable, Player
from random import randint, choice
from utils import vec, RESOLUTION, rectAdd


'''
            how to prevent objects from being on top of one another
'''

class GameEngine(object):

    def __init__(self):

        self.lyst = []
        #self.lyst.append(tuple([1,5]))


        self.player = Player((450,300))
        self.hunter = Drawable((10,0), "hunter.png")
        self.size = vec(*RESOLUTION)
        self.background = Drawable((0,0), "background.png")

        self.freeze = False
        self.freezeTime = 0
        self.time = 0    

        self.keys = []
        self.trees = []
        x_options = [0,450,940]
        x_exit = choice(x_options)
        if x_exit == 0 or x_exit == 940:
            self.exit = Drawable((x_exit,330), "exit.png")
            self.lyst.append(tuple([(self.exit.position[0]//10),(self.exit.position[1]//10)]))
        else:
            y_exit = [0,675]
            self.exit = Drawable((x_exit, choice(y_exit)), "exit.png")
            self.lyst.append(tuple([(self.exit.position[0]//10),(self.exit.position[1]//10)]))
        
        for i in range(8):  # unsure of what number to add
            while True:
                x = randint(0,900)
                y = randint(0,600)
                t = tuple([(x//15), (y//15)])
                if t not in self.lyst:
                    self.trees.append(Drawable((x,y), "tree.png"))
                    self.lyst.append(t)
                    break


        for i in range(5):
            while True:    #needs to inforce keys are not on top of one another
                x = randint(0,900)
                y = randint(0,600)
                t = tuple([(x//15), (y//15)])
                if t not in self.lyst:
                    self.keys.append(Drawable((x,y), "key.png"))
                    self.lyst.append(t)
                    break

        self.ice = []
        while True:
            x_ice = randint(0,900)
            y_ice = randint(0,600)
            t = tuple([(x_ice//15), (y_ice//15)])
            if t not in self.lyst:
                self.ice.append(Drawable((x_ice,y_ice), "ice.png"))
                self.lyst.append(t)
                break
        

    def draw(self, drawSurface):        
        #self.background.draw(drawSurface)
        drawSurface.fill((0,40,13))
        
        self.player.draw(drawSurface)
        for k in self.keys:
            k.draw(drawSurface)

        for t in self.trees:
            t.draw(drawSurface)
        

        self.hunter.draw(drawSurface)

        for i in self.ice:
            i .draw(drawSurface)
        
        if len(self.keys) == 0:
            self.exit.draw(drawSurface)
        

    def handleEvent(self, event):
        self.player.handleEvent(event)

    
    def update(self, seconds):
        #print(self.lyst)
        self.time+=seconds

        if self.time > 15:
            while True:
                x = randint(0,900)
                y = randint(0,600)
                t = tuple([(x//15), (y//15)])
                if t not in self.lyst:
                    self.ice.append(Drawable((x,y), "ice.png"))
                    self.lyst.append(t)
                    self.time=0
                    break

        #print(self.time)
        self.player.update(seconds)

        if self.freeze == True:
            self.freezeTime += seconds
            if self.freezeTime > 5:
                self.freeze = False
                self.freezeTime = 0

        if self.freeze == False:
            if self.player.position[0] > self.hunter.position[0]:
                self.hunter.position[0] += 1
            else:
                self.hunter.position[0] -= 1
            if self.player.position[1] > self.hunter.position[1]:
                self.hunter.position[1] += 1
            else:
                self.hunter.position[1] -= 1
        

        playerHitBox = rectAdd(self.player.position, self.player.image.get_rect())

        for k in range(len(self.keys)):
            keyHitBox = rectAdd(self.keys[k].position, self.keys[k].image.get_rect())
            if keyHitBox.colliderect(playerHitBox):
                self.keys.pop(k)
                break

        for i in range(len(self.ice)):
            iceHitBox = rectAdd(self.ice[i].position, self.ice[i].image.get_rect())
            if iceHitBox.colliderect(playerHitBox):
                self.ice.pop(i)
                self.freeze = True
                break

        exitHitBox = rectAdd(self.exit.position, self.exit.image.get_rect())
        if len(self.keys) == 0:
            if exitHitBox.colliderect(playerHitBox):
                return "win"
            
        hunterHitBox = rectAdd(self.hunter.position, pygame.Rect(20,15,30,47))
        if hunterHitBox.colliderect(playerHitBox):
            return "lose"
        
        
        for t in range(len(self.trees)):
            treeHitBox = rectAdd(self.trees[t].position, pygame.Rect(20,15,30,47))
            if treeHitBox.colliderect(playerHitBox):
                r = treeHitBox.clip(playerHitBox)
                if r.width > r.height:
                    if self.player.position[1] > self.trees[t].position[1]:
                        self.player.position[1] += r.height
                    else:
                        self.player.position[1] -= r.height
                else:
                    if self.player.position[0] > self.trees[t].position[0]:
                        self.player.position[0] += r.width
                    else:
                        self.player.position[0] -= r.width
                break 
                            
        Drawable.updateOffset(self.player, self.size)
    