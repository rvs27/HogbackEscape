from . import Mobile
from FSMs import WalkingFSM, AccelerationFSM
from utils import vec, RESOLUTION

from pygame.locals import *

import pygame
import numpy as np


class Hunter(Mobile):
   def __init__(self, position):
      super().__init__(position, "kirby.png")

   def handleEvent(self, event):
      pass

   def update(self, seconds): 
      super().update(seconds)

   def updateMovement(self):
      pass
   
              

  