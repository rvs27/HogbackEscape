from . import AbstractGameFSM
from statemachine import State
#from gameObjects import GameEngine

class ScreenManagerFSM(AbstractGameFSM):
    mainMenu = State(initial=True)
    game     = State()
    paused   = State()
    winMenu = State()
    loseMenu = State()
    pause = game.to(paused) | paused.to(game) | \
            mainMenu.to.itself(internal=True)
    
    startGame = mainMenu.to(game) 
    quitGame  = game.to(mainMenu) | \
                paused.to.itself(internal=True)
    winGame = game.to(winMenu)
    loseGame = game.to(loseMenu)
    restartGame = winMenu.to(game) | loseMenu.to(game)
    
    def isInGame(self):
        return self == "game" or self == "paused"
    
    def on_enter_game(self):
        self.obj.game.player.updateMovement()
    
    '''
    
    def on_enter_win(self):
        self.obj.game = GameEngine()

    def on_enter_game(self):
        self.obj.game = GameEngine()
    
    '''